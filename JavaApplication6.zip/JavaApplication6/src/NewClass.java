import java.util.*;
import java.lang.Math;

public class NewClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the expression:");
        String expression = scanner.nextLine();
        scanner.close();

        double result = evaluateExpression(expression);
        System.out.println("Result: " + result);
    }

    public static double evaluateExpression(String expression) {
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            if (Character.isDigit(ch)) {
                StringBuilder num = new StringBuilder();
                while (i < expression.length() && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
                    num.append(expression.charAt(i));
                    i++;
                }
                i--;
                numbers.push(Double.parseDouble(num.toString()));
            } else if (ch == '(') {
                operators.push(ch);
            } else if (ch == ')') {
                while (operators.peek() != '(') {
                    double result = applyOperator(operators.pop(), numbers.pop(), numbers.pop());
                    numbers.push(result);
                }
                operators.pop(); // Discard '('
            } else if (isOperator(ch)) {
                while (!operators.empty() && hasPrecedence(ch, operators.peek())) {
                    double result = applyOperator(operators.pop(), numbers.pop(), numbers.pop());
                    numbers.push(result);
                }
                operators.push(ch);
            }
        }

        while (!operators.empty()) {
            double result = applyOperator(operators.pop(), numbers.pop(), numbers.pop());
            numbers.push(result);
        }

        return numbers.pop();
    }

    public static boolean isOperator(char op) {
        return op == '+' || op == '-' || op == '*' || op == '/' || op == '^' || op == '√' || op == 'l' || op == 's' || op == 'c' || op == 't';
    }

    public static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')')
            return false;
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
            return false;
        if ((op1 == '^' || op1 == '√' || op1 == 'l' || op1 == 's' || op1 == 'c' || op1 == 't') && (op2 == '+' || op2 == '-' || op2 == '*' || op2 == '/'))
            return false;
        return true;
    }

    public static double applyOperator(char operator, double b, double a) {
        switch (operator) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0) throw new ArithmeticException("Division by zero");
                return a / b;
            case '^':
                return Math.pow(a, b);
            case '√':
                return Math.sqrt(b);
            case 'l':
                return Math.log10(b);
            case 's':
                return Math.sin(Math.toRadians(b));
            case 'c':
                return Math.cos(Math.toRadians(b));
            case 't':
                return Math.tan(Math.toRadians(b));
            default:
                throw new IllegalArgumentException("Invalid operator");
        }
    }
}
